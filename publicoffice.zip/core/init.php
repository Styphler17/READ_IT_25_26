<?php

require_once '../app/config/params.php';
require_once '../core/constantes.php';
require_once '../core/connection.php';
require_once '../core/helpers.php';
