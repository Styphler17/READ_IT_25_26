<form action="users/login" method="post">
    <h1 class="mb-3 h1">User Connection</h1>
    <div>
        <label for="email">Email</label>
        <input type="text" id="email" name="email" placeholder="alex.doe@gmail.com">
    </div>
    <div>
        <label for="email">Password</label>
        <input type="password" id="password" name="password">
    </div>
    <div>
        <input type="submit">
    </div>
</form>