<section class="ftco-section ftco-degree-bg">
    <div class="container">
        <div class="row">
            <div class="col-lg-8 ftco-animate">
                <div class="container">
                    <?php echo $content; ?>
                </div>
            </div>

            <?php include '../app/views/templates/partials/_aside.php'; ?>

        </div>
    </div>
</section> <!-- .section -->