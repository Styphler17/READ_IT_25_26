<?php

// Initialisation des zones dynamiques
$content = '';
$title = '';

// Paramètres de connexion
define('DB_HOST', 'localhost:8889');
define('DB_NAME', 'readit_2020');
define('DB_USER', 'root');
define('DB_PWD', 'root');
