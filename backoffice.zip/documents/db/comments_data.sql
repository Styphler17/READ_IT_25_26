INSERT INTO comments (pseudo,content,created_at,post_id)
VALUES
  ("Carol Conway","Donec consectetuer mauris id sapien. Cras dolor dolor, tempus","2020-12-23 11:19:52",55),
  ("Jason Soto","congue a, aliquet vel, vulputate eu, odio. Phasellus","2020-12-17 01:57:12",100),
  ("Camden Lambert","nunc sit amet metus. Aliquam erat volutpat.","2021-02-26 19:42:34",67),
  ("Daria Ford","Donec est mauris, rhoncus id,","2020-08-15 18:32:46",18),
  ("Gil Pitts","faucibus orci luctus et ultrices posuere cubilia Curae","2020-11-10 08:20:41",64),
  ("Cruz Bass","ante ipsum primis in faucibus orci luctus et ultrices","2020-07-04 09:50:31",55),
  ("Reece Harding","sem magna nec quam. Curabitur vel lectus.","2020-08-15 11:08:03",52),
  ("Hoyt Mack","lorem vitae odio sagittis semper. Nam tempor diam dictum","2020-12-10 12:01:40",65),
  ("Ashton Henderson","dictum ultricies ligula. Nullam enim. Sed","2021-01-15 23:25:41",79),
  ("Lynn Frost","et malesuada fames ac turpis egestas. Fusce aliquet magna","2021-02-02 07:55:58",47);
INSERT INTO comments (pseudo,content,created_at,post_id)
VALUES
  ("Darryl Ochoa","consequat, lectus sit amet luctus vulputate, nisi sem semper erat,","2020-05-14 17:31:15",71),
  ("Dorothy Holder","Donec vitae erat vel pede blandit","2020-10-24 17:58:53",36),
  ("Lara Powers","ligula elit, pretium et, rutrum non,","2020-10-03 05:50:29",10),
  ("Lester Jefferson","aliquet odio. Etiam ligula tortor,","2020-07-30 14:35:07",84),
  ("Marsden Garcia","Nam tempor diam dictum sapien. Aenean massa. Integer vitae nibh.","2020-08-13 06:48:13",64),
  ("Willow Murphy","sem mollis dui, in sodales elit","2020-07-28 00:58:38",32),
  ("Nayda Frost","eros. Nam consequat dolor vitae dolor. Donec fringilla.","2020-04-05 10:25:53",34),
  ("Demetrius Sellers","pretium aliquet, metus urna convallis erat, eget tincidunt","2020-10-19 21:06:01",88),
  ("Wallace Dillard","dictum eu, eleifend nec, malesuada ut, sem.","2020-10-07 14:22:39",90),
  ("Raja Santos","et, commodo at, libero. Morbi accumsan laoreet ipsum. Curabitur consequat,","2021-01-24 09:42:19",20);
INSERT INTO comments (pseudo,content,created_at,post_id)
VALUES
  ("Violet Haley","eget varius ultrices, mauris ipsum porta elit,","2020-10-22 10:37:52",96),
  ("Tasha Mills","mauris. Integer sem elit, pharetra ut, pharetra sed, hendrerit a,","2020-04-05 00:44:49",49),
  ("Oleg Abbott","dictum eleifend, nunc risus varius orci,","2020-04-10 20:28:05",26),
  ("Urielle Gilbert","ultrices posuere cubilia Curae Donec tincidunt. Donec vitae erat vel","2020-03-20 00:05:58",3),
  ("Elijah Wood","et magnis dis parturient montes, nascetur ridiculus","2020-07-25 13:08:22",16),
  ("Stephen Case","Proin nisl sem, consequat nec, mollis vitae,","2020-03-20 19:36:21",63),
  ("Patrick Villarreal","nascetur ridiculus mus. Donec dignissim magna a tortor. Nunc","2020-07-27 05:15:21",49),
  ("Darius Mccarty","leo. Cras vehicula aliquet libero. Integer in magna. Phasellus","2020-03-15 06:23:39",32),
  ("Tiger Moses","Nullam vitae diam. Proin dolor. Nulla semper tellus id","2020-04-07 10:02:36",64),
  ("Kenneth Woodward","Nullam lobortis quam a felis ullamcorper viverra.","2020-05-26 07:07:43",84);
INSERT INTO comments (pseudo,content,created_at,post_id)
VALUES
  ("Quon Hart","eget metus. In nec orci. Donec nibh. Quisque nonummy ipsum","2020-05-04 09:12:56",59),
  ("Ahmed Kaufman","magna. Cras convallis convallis dolor. Quisque tincidunt pede ac","2020-04-12 12:16:08",65),
  ("Medge Boyd","massa. Integer vitae nibh. Donec est","2020-12-17 12:14:56",4),
  ("Asher Rutledge","Duis elementum, dui quis accumsan","2020-10-10 07:56:17",17),
  ("Stella Buchanan","lobortis, nisi nibh lacinia orci, consectetuer euismod est arcu ac","2021-01-24 21:40:10",27),
  ("Charde Montgomery","Proin velit. Sed malesuada augue ut lacus. Nulla tincidunt, neque","2021-01-28 17:19:46",43),
  ("Dorian Mckay","elementum, dui quis accumsan convallis, ante lectus convallis est,","2020-06-13 22:36:44",53),
  ("Bree Weber","sit amet ornare lectus justo eu arcu. Morbi sit amet","2020-04-10 20:10:25",88),
  ("Imani Bender","porttitor tellus non magna. Nam ligula","2020-10-14 23:05:13",87),
  ("Chiquita Campos","arcu. Aliquam ultrices iaculis odio. Nam","2021-01-14 03:36:15",43);
INSERT INTO comments (pseudo,content,created_at,post_id)
VALUES
  ("Hedley Riggs","Curabitur sed tortor. Integer aliquam","2020-10-02 07:24:56",67),
  ("Camille Dodson","eleifend egestas. Sed pharetra, felis eget varius ultrices,","2020-06-06 00:35:27",68),
  ("Graiden Phillips","bibendum ullamcorper. Duis cursus, diam at pretium aliquet, metus","2021-02-18 21:58:55",34),
  ("Althea Curtis","purus ac tellus. Suspendisse sed","2021-02-23 12:33:56",43),
  ("Basia Ellison","magna. Ut tincidunt orci quis lectus. Nullam suscipit,","2020-08-12 17:21:27",4),
  ("Zachery Bradford","suscipit, est ac facilisis facilisis,","2020-03-08 06:48:00",89),
  ("Richard Brock","dignissim. Maecenas ornare egestas ligula. Nullam feugiat placerat","2020-10-17 21:36:47",7),
  ("Bernard Frederick","amet ante. Vivamus non lorem vitae odio sagittis","2020-12-30 17:46:50",80),
  ("Bryar Mays","ac mattis velit justo nec ante.","2020-12-14 05:41:01",61),
  ("Hayley Thornton","Maecenas iaculis aliquet diam. Sed diam","2020-07-02 16:27:07",14);
INSERT INTO comments (pseudo,content,created_at,post_id)
VALUES
  ("Seth Keller","id magna et ipsum cursus vestibulum. Mauris magna. Duis","2020-07-22 04:45:10",68),
  ("Naida Knowles","enim. Mauris quis turpis vitae purus gravida","2020-12-13 01:24:48",98),
  ("Gregory Sanchez","urna suscipit nonummy. Fusce fermentum fermentum arcu. Vestibulum","2020-10-09 02:43:21",59),
  ("Baker Bowen","Lorem ipsum dolor sit amet, consectetuer adipiscing","2020-07-25 09:51:21",64),
  ("Amos Ramos","a mi fringilla mi lacinia","2020-12-11 06:29:46",98),
  ("Meredith Wise","auctor. Mauris vel turpis. Aliquam adipiscing lobortis","2020-04-17 16:11:44",49),
  ("Calista Strickland","nascetur ridiculus mus. Aenean eget magna. Suspendisse tristique neque","2020-04-25 00:49:46",28),
  ("Hanna Heath","gravida molestie arcu. Sed eu nibh vulputate mauris sagittis placerat.","2020-09-26 09:36:37",100),
  ("Hammett Mcpherson","leo. Cras vehicula aliquet libero. Integer in magna. Phasellus","2021-01-02 21:26:06",18),
  ("Mari Workman","turpis egestas. Fusce aliquet magna a neque. Nullam ut nisi","2020-11-06 13:21:51",27);
INSERT INTO comments (pseudo,content,created_at,post_id)
VALUES
  ("Xavier Pruitt","Suspendisse eleifend. Cras sed leo. Cras vehicula aliquet libero.","2020-05-18 06:26:25",27),
  ("Hakeem Booth","nisi. Cum sociis natoque penatibus et magnis","2020-04-02 02:45:32",100),
  ("Ryder Macdonald","volutpat. Nulla dignissim. Maecenas ornare egestas ligula. Nullam feugiat","2020-04-16 08:37:10",94),
  ("Bevis Hull","Nulla tempor augue ac ipsum. Phasellus","2020-06-29 12:23:59",53),
  ("Micah Freeman","dolor. Fusce feugiat. Lorem ipsum dolor sit","2021-02-28 07:21:58",38),
  ("Kiona Bolton","ridiculus mus. Donec dignissim magna a tortor. Nunc","2020-07-26 14:27:55",82),
  ("Lana Chen","cubilia Curae Donec tincidunt. Donec","2020-12-06 23:12:41",35),
  ("Myles Goodwin","Sed dictum. Proin eget odio. Aliquam vulputate ullamcorper magna. Sed","2021-02-04 11:27:17",70),
  ("Harding Parrish","elit pede, malesuada vel, venenatis vel, faucibus id,","2020-11-08 07:31:15",100),
  ("Shay Maynard","lacus. Ut nec urna et arcu imperdiet ullamcorper. Duis","2020-12-17 13:52:20",5);
INSERT INTO comments (pseudo,content,created_at,post_id)
VALUES
  ("Alea Mcfadden","mi lorem, vehicula et, rutrum eu, ultrices","2020-03-15 00:57:28",2),
  ("Athena Jacobson","Aenean euismod mauris eu elit. Nulla facilisi. Sed neque.","2020-04-07 04:04:17",56),
  ("Jack Roth","dui, semper et, lacinia vitae, sodales at,","2020-05-17 21:42:59",32),
  ("Avram Rocha","blandit. Nam nulla magna, malesuada","2021-02-21 23:31:25",5),
  ("Jamal Wade","elementum at, egestas a, scelerisque sed, sapien. Nunc pulvinar","2021-02-17 09:18:37",20),
  ("Ayanna Hall","condimentum. Donec at arcu. Vestibulum ante","2020-11-26 03:39:05",35),
  ("Hilel Horn","elit, pretium et, rutrum non,","2020-07-13 20:36:53",32),
  ("Belle Flowers","parturient montes, nascetur ridiculus mus. Proin vel nisl.","2020-12-21 01:12:55",7),
  ("Chantale Henson","adipiscing elit. Aliquam auctor, velit eget laoreet posuere,","2020-08-21 15:14:46",97),
  ("Jason Cameron","tellus, imperdiet non, vestibulum nec,","2021-01-07 05:16:24",10);
INSERT INTO comments (pseudo,content,created_at,post_id)
VALUES
  ("Preston Graham","congue, elit sed consequat auctor, nunc nulla","2020-08-08 05:31:49",36),
  ("Ivana Sloan","Nunc quis arcu vel quam dignissim pharetra.","2020-07-10 05:27:01",25),
  ("Fitzgerald Willis","neque venenatis lacus. Etiam bibendum fermentum metus.","2021-01-24 05:02:41",91),
  ("Ryder Swanson","velit egestas lacinia. Sed congue, elit sed consequat","2020-06-08 20:56:26",79),
  ("Cheryl Hogan","eget metus eu erat semper rutrum. Fusce","2020-07-18 17:20:06",14),
  ("Kimberley Walters","ut lacus. Nulla tincidunt, neque vitae","2020-03-11 11:27:04",18),
  ("Kibo Gonzales","sapien, cursus in, hendrerit consectetuer, cursus et, magna. Praesent","2021-01-01 16:13:14",75),
  ("Regina Gay","Suspendisse aliquet molestie tellus. Aenean egestas hendrerit neque. In","2020-03-20 13:23:19",10),
  ("Aquila Davenport","risus. Donec egestas. Duis ac arcu.","2020-05-15 06:26:11",74),
  ("Hayley Kane","ante blandit viverra. Donec tempus, lorem fringilla","2021-01-16 07:03:10",28);
INSERT INTO comments (pseudo,content,created_at,post_id)
VALUES
  ("Roary Wolf","eget metus. In nec orci. Donec nibh. Quisque","2021-02-13 23:34:33",87),
  ("Emi Randall","Nullam lobortis quam a felis ullamcorper viverra. Maecenas iaculis","2020-07-14 18:15:28",41),
  ("Arthur Blackwell","arcu. Vestibulum ut eros non enim","2020-03-06 15:52:29",32),
  ("Yvonne Ryan","pede ac urna. Ut tincidunt vehicula risus.","2020-07-10 14:33:45",5),
  ("Alyssa Goodman","velit eget laoreet posuere, enim nisl elementum purus, accumsan","2020-10-07 06:03:49",95),
  ("Lani West","Integer vitae nibh. Donec est mauris, rhoncus id,","2021-02-08 06:42:04",95),
  ("Lani Erickson","et pede. Nunc sed orci lobortis augue","2020-06-21 17:01:32",60),
  ("Norman Wallace","Fusce mi lorem, vehicula et, rutrum eu,","2021-01-26 13:23:54",3),
  ("Ann Solomon","velit egestas lacinia. Sed congue, elit","2020-12-04 05:35:51",34),
  ("Mira Hobbs","odio. Etiam ligula tortor, dictum eu, placerat","2020-11-04 14:44:09",45);
